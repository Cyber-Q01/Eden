import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

function parseImages(images: unknown): string[] {
  if (Array.isArray(images)) return images;
  if (typeof images === 'string') {
    try {
      const parsed = JSON.parse(images);
      return Array.isArray(parsed) ? parsed : [images];
    } catch {
      return images.length > 0 ? [images] : [];
    }
  }
  return [];
}

function createUserClient(req: Request) {
  const authHeader = req.headers.get('Authorization');
  if (!authHeader) throw new Error('Missing Authorization header');

  return createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    { global: { headers: { Authorization: authHeader } } }
  );
}

async function getUserId(req: Request): Promise<string> {
  const supabase = createUserClient(req);
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) throw new Error('Unauthorized');
  return user.id;
}

function errorResponse(message: string, status = 400) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabase = createUserClient(req);
    const userId = await getUserId(req);

    // ── GET: Fetch conversations ────────────────────────────────────────
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('conversations')
        .select(`
          *,
          participant_a:users!conversations_participant_a_id_fkey(first_name, email),
          participant_b:users!conversations_participant_b_id_fkey(first_name, email)
        `)
        .or(`participant_a_id.eq.${userId},participant_b_id.eq.${userId}`)
        .order('last_message_at', { ascending: false });

      if (error) return errorResponse(error.message, 500);
      return jsonResponse(data ?? []);
    }

    // ── POST: Start or get existing conversation ────────────────────────
    if (req.method === 'POST') {
      const { other_user_id } = await req.json();
      if (!other_user_id) return errorResponse('Missing other_user_id');

      // Check if conversation already exists (either direction)
      const { data: existing } = await supabase
        .from('conversations')
        .select('id')
        .or(
          `and(participant_a_id.eq.${userId},participant_b_id.eq.${other_user_id}),` +
          `and(participant_a_id.eq.${other_user_id},participant_b_id.eq.${userId})`
        )
        .single();

      if (existing) {
        return jsonResponse({ id: existing.id });
      }

      // Create new
      const { data: created, error } = await supabase
        .from('conversations')
        .insert({ participant_a_id: userId, participant_b_id: other_user_id })
        .select('id')
        .single();

      if (error) return errorResponse(error.message, 500);
      return jsonResponse({ id: created?.id }, 201);
    }

    return errorResponse('Method not allowed', 405);
  } catch (e) {
    return errorResponse(e.message, 401);
  }
});
