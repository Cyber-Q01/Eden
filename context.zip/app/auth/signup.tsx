import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import CustomButton from '../../components/CustomButton';
import ScreenWrapper from '../../components/ScreenWrapper';
import ThemedTextInput from '../../components/ThemedTextInput';
import { useToast } from '../../components/Toast';
import { useTheme } from '../../context/ThemeContext';
import { supabase } from '../../lib/supabase';
import { useUser } from '../../context/UserContext';
import { handleError } from '../../lib/errorHandler';
import { sanitizeName, sanitizeEmail, validateName, validateEmail, validatePassword, validateAll } from '../../lib/validation';

const SignupScreen = () => {
    const router = useRouter();
    const { colors } = useTheme();
    const { userType } = useUser();
    const { showError, showSuccess } = useToast();
    
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleSignup = async () => {
        const error = validateAll([
            { check: () => validateName(firstName, 'First name') },
            { check: () => validateName(lastName, 'Last name') },
            { check: () => validateEmail(email) },
            { check: () => validatePassword(password) },
        ]);
        if (error) {
            showError({ type: 'unknown', title: 'Validation Error', message: error });
            return;
        }
        if (password !== confirmPassword) {
            showError({ type: 'unknown', title: 'Passwords Mismatch', message: 'Passwords do not match. Please try again.' });
            return;
        }

        const cleanFirst = sanitizeName(firstName);
        const cleanLast = sanitizeName(lastName);
        const cleanEmail = sanitizeEmail(email);

        setLoading(true);
        try {
            const { data, error: authError } = await supabase.auth.signUp({
                email: cleanEmail,
                password,
                options: {
                    data: {
                        firstName: cleanFirst,
                        lastName: cleanLast,
                        role: userType ? userType.toUpperCase() : 'TENANT'
                    }
                }
            });
            if (authError) throw authError;
            showSuccess('Check your email for the verification code.');
            router.push({ pathname: '/auth/verification', params: { email: cleanEmail } });
        } catch (e) {
            const err = await handleError(e);
            showError(err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <ScreenWrapper>
            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                <View style={styles.topSection}>
                    <Image
                        source={require('../../assets/images/EdenIcon.png')}
                        style={styles.icon}
                        resizeMode="contain"
                    />
                    <Text style={styles.title}>Create your Account</Text>
                </View>

                <View style={styles.formContainer}>
                    <ThemedTextInput
                        placeholder="First Name"
                        value={firstName}
                        onChangeText={(t) => setFirstName(sanitizeName(t))}
                    />

                    <ThemedTextInput
                        placeholder="Last Name"
                        value={lastName}
                        onChangeText={(t) => setLastName(sanitizeName(t))}
                    />

                    <ThemedTextInput
                        placeholder="Email address"
                        value={email}
                        onChangeText={setEmail}
                        autoCapitalize={'none'}
                        keyboardType="email-address"
                    />

                    <ThemedTextInput
                        placeholder="Password"
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry={!showPassword}
                        rightIcon={
                            <TouchableOpacity style={styles.eyeIcon} onPress={() => setShowPassword(!showPassword)}>
                                <Ionicons name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={20} color={colors.textSecondary} />
                            </TouchableOpacity>
                        }
                    />

                    <ThemedTextInput
                        placeholder="Confirm Password"
                        value={confirmPassword}
                        onChangeText={setConfirmPassword}
                        secureTextEntry={!showConfirmPassword}
                        rightIcon={
                            <TouchableOpacity style={styles.eyeIcon} onPress={() => setShowConfirmPassword(!showConfirmPassword)}>
                                <Ionicons name={showConfirmPassword ? 'eye-off-outline' : 'eye-outline'} size={20} color={colors.textSecondary} />
                            </TouchableOpacity>
                        }
                    />

                    <CustomButton
                        title={loading ? "Signing up..." : "Sign Up"}
                        onPress={handleSignup}
                        style={styles.signupButton}
                        disabled={loading}
                    />

                    <TouchableOpacity onPress={() => router.push('/auth/login')}>
                        <Text style={[styles.loginPrompt, { color: colors.textSecondary }]}>
                            Already have an Account ? <Text style={[styles.loginLink, { color: colors.primary }]}>Login</Text>
                        </Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.dividerContainer}>
                    <Text style={[styles.dividerText, { color: colors.textSecondary }]}>or</Text>
                </View>

                <View style={styles.socialContainer}>
                    <TouchableOpacity style={[styles.socialButton, { backgroundColor: colors.card, borderColor: colors.primary }]}>
                        <Ionicons name="logo-facebook" size={24} color="#1877F2" />
                        <Text style={[styles.socialButtonText, { color: colors.text }]}>Continue with Facebook</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.socialButton, { backgroundColor: colors.card, borderColor: colors.primary }]}>
                        <Image
                            source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg' }}
                            style={{ width: 24, height: 24 }}
                        />
                        <Text style={[styles.socialButtonText, { color: colors.text }]}>Continue with Google</Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </ScreenWrapper>
    );
};

const styles = StyleSheet.create({
    scrollContent: {
        paddingHorizontal: 24,
        paddingVertical: 40,
    },
    topSection: {
        alignItems: 'center',
        marginBottom: 40,
    },
    icon: {
        width: 80,
        height: 80,
        marginBottom: 16,
    },
    title: {
        fontSize: 28,
        fontWeight: '800',
        color: '#0047AB',
        textAlign: 'center',
    },
    formContainer: {
        gap: 16,
    },
    inputWrapper: {
        height: 56,
        borderWidth: 1,
        borderColor: '#0047AB',
        borderRadius: 8,
        backgroundColor: '#FFFFFF',
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
    },
    input: {
        flex: 1,
        fontSize: 16,
        color: '#333',
    },
    eyeIcon: {
        padding: 8,
    },
    signupButton: {
        marginTop: 20,
    },
    loginPrompt: {
        textAlign: 'center',
        color: '#666',
        fontSize: 14,
        marginTop: 10,
    },
    loginLink: {
        color: '#0047AB',
        fontWeight: '600',
    },
    dividerContainer: {
        marginVertical: 30,
        alignItems: 'center',
    },
    dividerText: {
        color: '#666',
        fontSize: 16,
    },
    socialContainer: {
        gap: 12,
    },
    socialButton: {
        height: 56,
        borderWidth: 1,
        borderColor: '#0047AB',
        borderRadius: 12,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 12,
        backgroundColor: '#FFFFFF',
    },
    socialButtonText: {
        fontSize: 16,
        color: '#333',
        fontWeight: '500',
    },
});

export default SignupScreen;
